﻿using org.semanticweb.owlapi.model;
using org.semanticweb.owlapi.util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OntologyNet
{
    public static class OntologySave
    {
        public static string ERROR_HOLDER;

        public static bool SaveClassAssertion(String ClassName, String Individual)
        {
            try
            {
                ConnectOntology.CreateConnection();
                PrefixManager pm = new DefaultPrefixManager(ConnectOntology.Ont_Base_IRI);
                OWLClass person = ConnectOntology.f.getOWLClass(ClassName, pm);
                OWLNamedIndividual mary = ConnectOntology.f.getOWLNamedIndividual(Individual, pm);
                OWLClassAssertionAxiom classAssertion = ConnectOntology.f.getOWLClassAssertionAxiom(person, mary);
                ConnectOntology.m.addAxiom(ConnectOntology.o, classAssertion);
                ConnectOntology.m.saveOntology(ConnectOntology.o);
                return true;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }
        public static bool SaveDataPropertyAssertion(string Individual, string DataProperty, string Deger)
        {
            try
            {
                ConnectOntology.CreateConnection();
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + Individual));
                OWLDataProperty dproperty = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + DataProperty));
                OWLDataPropertyAssertionAxiom ax = ConnectOntology.f.getOWLDataPropertyAssertionAxiom(dproperty, domain, Deger);
                if (!ConnectOntology.o.containsAxiom(ax))
                {
                    AddAxiom addAx = new AddAxiom(ConnectOntology.o, ax);
                    ConnectOntology.m.applyChange(addAx);
                    ConnectOntology.m.saveOntology(ConnectOntology.o);
                    return true;
                }else return false;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

        public static bool SaveDataPropertyAssertion(String indv, String dprop, double deger)
        {
            try
            {
                ConnectOntology.CreateConnection();
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + indv));
                OWLDataProperty dproperty = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + dprop));
                OWLDataPropertyAssertionAxiom ax = ConnectOntology.f.getOWLDataPropertyAssertionAxiom(dproperty, domain, deger);
                if (!ConnectOntology.o.containsAxiom(ax))
                {
                    AddAxiom addAx = new AddAxiom(ConnectOntology.o, ax);
                    ConnectOntology.m.applyChange(addAx);
                    ConnectOntology.m.saveOntology(ConnectOntology.o);
                    return true;
                }
                else return false;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

        public static bool SaveDataPropertyAssertion(String indv, String dprop, int deger)
        {
            try
            {
                ConnectOntology.CreateConnection();
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + indv));
                OWLDataProperty dproperty = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + dprop));
                OWLDataPropertyAssertionAxiom ax = ConnectOntology.f.getOWLDataPropertyAssertionAxiom(dproperty, domain, deger);
                if (!ConnectOntology.o.containsAxiom(ax))
                {
                    AddAxiom addAx = new AddAxiom(ConnectOntology.o, ax);
                    ConnectOntology.m.applyChange(addAx);
                    ConnectOntology.m.saveOntology(ConnectOntology.o);
                    return true;
                }
                else return false;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }
    }
}
