﻿using com.clarkparsia.pellet.owlapiv3;
using org.semanticweb.owlapi.apibinding;
using org.semanticweb.owlapi.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OntologyNet
{
    public static class ConnectOntology
    {
        public static string localLocation_IRI = @"\owl\ontology.owl";
        public static string Ont_Base_IRI = "http://www.erkteknoloji.com/owl/ontology.owl#";
        public static OWLOntologyManager m;
        public static OWLDataFactory f;
        public static OWLOntology o;
        public static PelletReasoner r;

        public static string ERROR_HOLDER;

        public static void CreateConnection()
        {
            try
            {
                m = OWLManager.createOWLOntologyManager();
                f = m.getOWLDataFactory();
                java.io.File file = new java.io.File(System.IO.Directory.GetCurrentDirectory() + localLocation_IRI);
                o = m.loadOntologyFromOntologyDocument(file);
                r = PelletReasonerFactory.getInstance().createReasoner(o);
            }
            catch(Exception ex)
            {
                ERROR_HOLDER = ex.Message;
            }

        }
        public static void CloseConnection()
        {
            m.removeOntology(o);
        }
    }
}
