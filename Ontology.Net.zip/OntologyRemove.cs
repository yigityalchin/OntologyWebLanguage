﻿using org.semanticweb.owlapi.io;
using org.semanticweb.owlapi.model;
using org.semanticweb.owlapi.util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OntologyNet
{
    public static class OntologyRemove
    {
        public static string ERROR_HOLDER;

        public static bool RemoveClassAssertion(String ClassName, String Individual)
        {
            try
            {
                ConnectOntology.CreateConnection();
                OWLClass cust = ConnectOntology.f.getOWLClass(IRI.create(ConnectOntology.Ont_Base_IRI + ClassName));
                OWLNamedIndividual oni = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + Individual));
                OWLClassAssertionAxiom ax = ConnectOntology.f.getOWLClassAssertionAxiom(cust, oni);
                // save in OWL/XML format
                if (ConnectOntology.o.containsAxiom(ax))
                {
                    ConnectOntology.m.applyChange(new RemoveAxiom(ConnectOntology.o, ax));
                    ConnectOntology.m.saveOntology(ConnectOntology.o);
                }
                return true;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

        public static bool RemoveIndividual(string Individual)
        {
            try
            {
                ConnectOntology.CreateConnection();
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + Individual));
                OWLEntityRemover rem = new OWLEntityRemover(ConnectOntology.m, java.util.Collections.singleton(ConnectOntology.o));
                domain.accept(rem);
                ConnectOntology.m.applyChanges(rem.getChanges());
                ConnectOntology.m.saveOntology(ConnectOntology.o);
                return true;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

        public static bool RemoveDataPropertyAssertion(string Individual, string DataPropery, string Deger)
        {
            try
            {
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + Individual));
                OWLDataProperty dproperty = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + DataPropery));
                OWLDataPropertyAssertionAxiom ax = ConnectOntology.f.getOWLDataPropertyAssertionAxiom(dproperty, domain, Deger);
                if (ConnectOntology.o.containsAxiom(ax))
                {
                    RemoveAxiom rax = new RemoveAxiom(ConnectOntology.o, ax);
                    ConnectOntology.m.applyChange(rax);
                    ConnectOntology.m.saveOntology(ConnectOntology.o, new OWLXMLOntologyFormat(), IRI.create(ConnectOntology.localLocation_IRI));
                }
                return true;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

        public static bool RemoveDataPropertyAssertion(string Individual, string DataPropery, double Deger)
        {
            try
            {
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + Individual));
                OWLDataProperty dproperty = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + DataPropery));
                OWLDataPropertyAssertionAxiom ax = ConnectOntology.f.getOWLDataPropertyAssertionAxiom(dproperty, domain, Deger);
                if (ConnectOntology.o.containsAxiom(ax))
                {
                    RemoveAxiom rax = new RemoveAxiom(ConnectOntology.o, ax);
                    ConnectOntology.m.applyChange(rax);
                    ConnectOntology.m.saveOntology(ConnectOntology.o, new OWLXMLOntologyFormat(), IRI.create(ConnectOntology.localLocation_IRI));
                }
                return true;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

        public static bool RemoveDataPropertyAssertion(string Individual, string DataPropery, int Deger)
        {
            try
            {
                OWLNamedIndividual domain = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + Individual));
                OWLDataProperty dproperty = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + DataPropery));
                OWLDataPropertyAssertionAxiom ax = ConnectOntology.f.getOWLDataPropertyAssertionAxiom(dproperty, domain, Deger);
                if (ConnectOntology.o.containsAxiom(ax))
                {
                    RemoveAxiom rax = new RemoveAxiom(ConnectOntology.o, ax);
                    ConnectOntology.m.applyChange(rax);
                    ConnectOntology.m.saveOntology(ConnectOntology.o, new OWLXMLOntologyFormat(), IRI.create(ConnectOntology.localLocation_IRI));
                }
                return true;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return false;
            }
        }

    }
}
