﻿using org.semanticweb.owlapi.model;
using org.semanticweb.owlapi.reasoner;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OntologyNet
{
    class OntologyFunctions
    {
        public static string ERROR_HOLDER;

        public static List<string> GetIndividualsByClassName(String ClassName)
        {
            List<string> individualList = new List<string>();
            try
            {
                ConnectOntology.CreateConnection();
                OWLClass cls = ConnectOntology.f.getOWLClass(IRI.create(ConnectOntology.Ont_Base_IRI + ClassName));
                java.util.Set individuals = ConnectOntology.r.getInstances(cls, true).getFlattened();
                java.util.Iterator it = individuals.iterator();
                while (it.hasNext())
                {
                    OWLNamedIndividual oni = (OWLNamedIndividual)it.next();
                    individualList.Add(IRI_Kes(oni.ToString()));
                }
                /*foreach (var ind in individuals)
                {
                }*/
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return null;
            }
            return individualList;
        }

        public static List<string> GetObjectPropertyValue(String IndividualName, String PropertyName)
        {
            List<string> ObjPropList = new List<string>();
            try
            {
                ConnectOntology.CreateConnection();
                OWLNamedIndividual cls = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + IndividualName));
                OWLObjectProperty pe = ConnectOntology.f.getOWLObjectProperty(IRI.create(ConnectOntology.Ont_Base_IRI + PropertyName));
                java.util.Set individuals = ConnectOntology.r.getObjectPropertyValues(cls, pe).getFlattened();
                java.util.Iterator it = individuals.iterator();
                while (it.hasNext())
                {
                    OWLNamedIndividual oni = (OWLNamedIndividual)it.next();
                    ObjPropList.Add(IRI_Kes(oni.ToString()));
                }
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return null;
            }
            return ObjPropList;
        }

        public static string GetDataPropertyValue(string IndividualName, string PropertyName)
        {
            try
            {
                ConnectOntology.CreateConnection();
                OWLNamedIndividual cls = ConnectOntology.f.getOWLNamedIndividual(IRI.create(ConnectOntology.Ont_Base_IRI + IndividualName));
                OWLDataProperty pe = ConnectOntology.f.getOWLDataProperty(IRI.create(ConnectOntology.Ont_Base_IRI + PropertyName));
                string value = ConnectOntology.r.getDataPropertyValues(cls, pe).ToString();
                value = IRI_Kes(value).Substring(2, value.IndexOf("^") - 3);
                return value;
            }
            catch (Exception ex)
            {
                ERROR_HOLDER = ex.Message;
                return ERROR_HOLDER;
            }
        }

        public static string IRI_Kes(string iri)
        {
            string Deger = iri.Substring(iri.IndexOf("#") + 1);
            Deger = Deger.Remove(Deger.Length - 1);
            return Deger;
        }

    }
}
